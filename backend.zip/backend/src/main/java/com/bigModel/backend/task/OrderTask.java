package com.bigModel.backend.task;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;

@Component
public class OrderTask {

    //    测试定时任务
//    每小时
    @Scheduled(cron = "0/20 * * * * ?")
    public void testHello() throws IOException, URISyntaxException {
        System.out.println(new Date().toInstant());
        String apiUrl = "https://api.twitter.com/2/tweets/search/recent?query=%E4%B9%A0%E8%BF%91%E5%B9%B3";
        String bearerToken = "Bearer AAAAAAAAAAAAAAAAAAAAAIRBrAEAAAAAgU%2BrSU6jqqQhmNjGbP9Vw24qUfI%3DyeaoWbeaoWvguoY0PWb56I0NFoGYbwIf8M9alsTWyuqThfi3Tq";

        HttpHeaders headers = new HttpHeaders();
        headers.add("User-Agent", "Apifox/1.0.0 (https://apifox.com)");
        headers.add("Authorization", bearerToken);
        headers.add("Accept", "*/*");
        headers.add("Host", "api.twitter.com");
        headers.add("Connection", "keep-alive");

        RequestEntity<String> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, new URI(apiUrl));

        ResponseEntity<String> responseEntity = new RestTemplate().exchange(requestEntity, String.class);

        // 处理响应，可以通过responseEntity.getBody()获取响应内容等
        System.out.println("Response: " + responseEntity.getBody());
    }

}
